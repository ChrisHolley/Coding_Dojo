from django.apps import AppConfig


class TvshowsConfig(AppConfig):
    name = 'TVshows'
